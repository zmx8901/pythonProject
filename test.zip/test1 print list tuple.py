# 测试print语句
print('%s' % 3.1415926)
print('Hello, %s,%s,%0.2f' % ('world', 3.1415926, 3.1415926))
# 如果你不太确定应该用什么，%s永远起作用，它会把任何数据类型转换为字符串：
print('Age: %s. Gender: %s' % (25, True))

classmates = ['Michael', 'Bob', 'Tracy']
classmates.append('henry')
print(classmates, classmates[:2], classmates[2], ',"len(classmates)="', len(classmates))
classmates.insert(1, 'alon')
print(classmates, classmates[:2], classmates[2], ',"len(classmates)="', len(classmates))
classmates.pop()
print(classmates)
classmates.pop(-2)
print(classmates)
classmates[-1] = 'lucky'
print(classmates)

kongmaomao = (1,)
print(kongmaomao)
# kongmaomao[1]=2 元组一旦初始化就不能修改,下一行为元组中的可变性，采用list为元素
t = ('a', 'b', ['A', 'B'])
t[2][0] = 'X'
t[2][1] = 'Y'
print(t)
L = [
    ['Apple', 'Google', 'Microsoft'],
    ['Java', 'Python', 'Ruby', 'PHP'],
    ['Adam', 'Bart', 'Lisa']
]
print(L[0][2], L[0: 2])
