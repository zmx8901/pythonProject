# -----计算圆的面积
import math


def roundarea(r):
    return math.pi * r ** 2


print("圆的面积为%.1f" % roundarea(float(input("请输入圆的半径："))))

