a, b = 1, 2
print(a, b)
