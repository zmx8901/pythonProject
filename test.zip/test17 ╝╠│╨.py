#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author：albert time:20/2/18
print(type(abs))
print(dir(abs))
len()